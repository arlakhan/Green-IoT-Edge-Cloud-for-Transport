import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SupplyChainSystem {
    private List<Block> blockchain;
    private GeneticAlgorithm ga;
    private DeepCNN cnn;

    public SupplyChainSystem() {
        this.blockchain = new ArrayList<>();
        this.ga = new GeneticAlgorithm();
        this.cnn = new DeepCNN();
    }

    public void loadData(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = br.readLine()) != null) {
            Block newBlock = new Block(line, blockchain.isEmpty() ? "0" : blockchain.get(blockchain.size() - 1).hash);
            blockchain.add(newBlock);
        }
        br.close();
    }

    public void optimizeAndAnalyze() {
        ga.optimize(blockchain);
        cnn.analyze(blockchain);
    }

    public Boolean validateBlockchain() {
        return Blockchain.isChainValid();
    }
}
